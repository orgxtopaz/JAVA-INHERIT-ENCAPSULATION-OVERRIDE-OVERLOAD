/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artist;

/**
 *
 * @author 2ndyrGroupA
 */
//ENCAPSULATIONS
public class rapper {
   private String name;
   private int age;
   
   
   public void rap(){
       System.out.println("I can rap : Inheritance");
   }
   
   
   public void rapperage(String name,int age){
       System.out.println("My name is "+ name +" my age is "+age +"Inheritance");
   }
   public void rapperage(String name,int age,String hobby){
       
   }
   
   public String Getname(){
       return name;
   }
   public void Setname(String Rappername){
      name = Rappername;
   }
   
   
   
}







