/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artist;

/**
 *
 * @author 2ndyrGroupA
 */
public class Artist {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
      
       
       
        rapper rap = new rapper();
        Singer sing = new Singer();
         //INHERITANCE
        rap.rap();
        sing.rap();
        rap.rapperage("migz", 10);
     
        //ENCAPSULATION
        rap.Setname("migz");
        System.out.println("RAPPER IS NAME"+ " "+rap.Getname() +"ENCAPSULATION");
      
        //System.out.println("arwr");
        
        
    }
    
    
}
