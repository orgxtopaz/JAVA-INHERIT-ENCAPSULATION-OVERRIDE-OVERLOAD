/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artist;

/**
 *
 * @author 2ndyrGroupA
 */
public class painter extends Artist {
    //AGGREGATION
    
  
    
    Singer sing;
    
    //INHERITANCE
    rapper rap;
    
    public void paint(){
        System.out.println("hes a painter");
    }
   
}
